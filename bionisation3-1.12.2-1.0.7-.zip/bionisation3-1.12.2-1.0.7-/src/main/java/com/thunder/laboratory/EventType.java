package com.thunder.laboratory;


public enum EventType {
    TICK, ATTACK, HURT, DEATH
}
