package com.thunder.laboratory;


public enum SampleType {
    EFFECT, VIRUS, BACTERIA, SYMBIOSIS, BACTERIA_CURE, VIRUS_CURE, EFFECT_CURE, CUSTOM_VIRUS, SYMBIONT
}
