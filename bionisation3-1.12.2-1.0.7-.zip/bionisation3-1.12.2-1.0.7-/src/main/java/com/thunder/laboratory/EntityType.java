package com.thunder.laboratory;

public enum EntityType {
    PLAYER, ENTITY
}
