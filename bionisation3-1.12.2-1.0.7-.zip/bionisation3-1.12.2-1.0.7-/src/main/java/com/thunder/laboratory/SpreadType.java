package com.thunder.laboratory;


public enum SpreadType {
    AIR, ATTACK, HURT
}
