package com.thunder.bionisation;


public class Information {

    public static final String MOD_NAME = "Bionisation 3";
    public static final String MOD_ID = "bionisation3";
    public static final String VERSION = "@VERSION@";
    public static final String COMMON_PROXY_PATH = "com.thunder.bionisation.CommonProxy";
    public static final String CLIENT_PROXY_PATH = "com.thunder.bionisation.ClientProxy";
}
