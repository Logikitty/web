/**
 * 病毒对象
 *
 * @ClassName: Virus
 * @Description: 病毒对象
 * @author: Bruce Young
 * @date: 2020年02月02日 17:04
 */
public class Virus {
}
