export const Moves: {[moveid: string]: ModdedMoveData} = {
	tailglow: {
		inherit: true,
		isNonstandard: undefined,
	},
};
